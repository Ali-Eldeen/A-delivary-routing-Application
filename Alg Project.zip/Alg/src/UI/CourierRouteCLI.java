package UI;

import courier.Location;
import courier.RouteOptimizer;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourierRouteCLI {
    private List<Location> locations;
    private Scanner scanner;

    public CourierRouteCLI() {
        locations = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            printMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    addLocations();
                    break;
                case 2:
                    addLocation_newtext();
                    break;
                case 3:
                    addnewLocation();
                    break;
                case 4:
                    removeLocation();
                    break;
                case 5:
                    optimizeRoute();
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

    }

    private void printMenu() {
        System.out.println("Courier Routing System");
        System.out.println("----------------------");
        System.out.println("1. Add locations from the text file");
        System.out.println("2. Add locations from a new text file");
        System.out.println("3. Add new location");
        System.out.println("4. Remove location");
        System.out.println("5. Optimize route");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    private int getUserChoice() {
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid choice. Please enter a number.");
            scanner.nextLine();
        }
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        return choice;
    }
    public double time_calc(double time){
        int counter=0;
        boolean f=false;
        double remaining_min = 0;
        while (time >=60){
            remaining_min= time%60;
            time-=60;
            counter++;
            f=true;
        }
        if((time<60)&&(f==false))
            return time/100;
        return counter+remaining_min/100;
    }
    /*
        Location location1 = new Location("Location 1", 12.345, 67.890, true,"12:00 PM");
        Location location2 = new Location("Location 2", 101.234, 156.789, false, "9:30 PM");
        Location location3 = new Location("Location 3", 34.567, 89.012, true, "2:45 PM");
        Location location4 = new Location("Location 4", 67.890, 112.345, false, "5:30 PM");
        Location location5 = new Location("Location 5", 56.789, 101.234, true, "4:00 PM");
        Location location6 = new Location("Location 6", 89.012, 134.567, false, "7:15 PM");
        Location location7 = new Location("Location 7", 78.901, 123.456, true, "6:45 PM");
        Location location8 = new Location("Location 8", 45.678, 90.123, false, "3:15 PM");
        Location location9 = new Location("Location 9", 90.123, 145.678, true, "8:00 PM");
        Location location10 = new Location("Location 10", 23.456, 78.901, false, "1:30 PM");

        locations.add(location1);
        locations.add(location2);
        locations.add(location3);
        locations.add(location4);
        locations.add(location5);
        locations.add(location6);
        locations.add(location7);
        locations.add(location8);
        locations.add(location9);
        locations.add(location10);

        System.out.println("Locations added successfully.");
     */


    /*
    System.out.println("Enter location details:");

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Latitude: ");
        double latitude = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Longitude: ");
        double longitude = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Is it a pickup location? (true/false): ");
        boolean isPickup = scanner.nextBoolean();
        scanner.nextLine();

        System.out.print("Deadline: ");
        String deadline = scanner.nextLine();

        Location location = new Location(name, latitude, longitude, isPickup, deadline);
        locations.add(location);

        System.out.println("Location added successfully.");
     */
    private void addnewLocation() {

        System.out.println("Enter location details:");

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Latitude: ");
        double latitude = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Longitude: ");
        double longitude = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Is it a pickup location? (true/false): ");
        boolean isPickup = scanner.nextBoolean();
        scanner.nextLine();

        System.out.print("Deadline: ");
        String deadline = scanner.nextLine();

        Location location = new Location(name, latitude, longitude, isPickup, deadline);
        locations.add(location);

        System.out.println("Location added successfully.");

    }
    private void addLocations() {

        File file = new File("/home/aloka/IdeaProjects/Alg/src/Orders.txt");
        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(file);
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }

        while (fileScanner.hasNextLine()) {
                    String line = fileScanner.nextLine();
                    String[] locationData = line.split(",");

                    String name = locationData[0].trim();
                    double latitude = Double.parseDouble(locationData[1].trim());
                    double longitude = Double.parseDouble(locationData[2].trim());
                    boolean pickup;
                    if (locationData[3].trim()=="Delivery")
                        pickup=false;
                    else
                        pickup=true;
                    String deadline = locationData[4].trim();

                    Location location = new Location(name, latitude, longitude, pickup, deadline);
                    locations.add(location);
                }

                System.out.println("Locations added successfully from the file.");

    }
    private void addLocation_newtext() {

        System.out.print("The path of the new text file: ");
        String path = scanner.nextLine();
        try{
        File file = new File(path);
        Scanner fileScanner = null;
        fileScanner = new Scanner(file);
        while (fileScanner.hasNextLine()) {
            String line = fileScanner.nextLine();
            String[] locationData = line.split(",");

            String name = locationData[0].trim();
            double latitude = Double.parseDouble(locationData[1].trim());
            double longitude = Double.parseDouble(locationData[2].trim());
            boolean pickup;
            if (locationData[3].trim()=="Delivery")
                pickup=false;
            else
                pickup=true;
            String deadline = locationData[4].trim();

            Location location = new Location(name, latitude, longitude, pickup, deadline);
            locations.add(location);
        }

        System.out.println("Locations added successfully from the file.");
        }catch (Exception e){
            System.out.println("File not found");
        }

    }
    /*
    Location: Location 1
    Location: Location 3
    Location: Location 5
    Location: Location 7
    Location: Location 9
    Location: Location 10
    Location: Location 8
    Location: Location 4
    Location: Location 6
    Location: Location 2
     */

    private void removeLocation() {
        System.out.print("Enter the name of the location to remove: ");
        String name = scanner.nextLine();

        boolean removed = false;
        for (Location location : locations) {
            if (location.getName().equalsIgnoreCase(name)) {
                locations.remove(location);
                removed = true;
                break;
            }
        }

        if (removed) {
            System.out.println("Location removed successfully.");
        } else {
            System.out.println("Location not found.");
        }
    }

    private void optimizeRoute() {
        if (locations.isEmpty()) {
            System.out.println("No locations added. Please add locations first.");
            return;
        }

        List<Location> optimizedRoute = RouteOptimizer.optimizeRoute(locations);

        System.out.println("Optimized Courier Route:\nLocations\t\tDistance\tEstimated time\tDeadline");
        int cnt=0;
        String Path="",begin="";
        double est=0,dead=0;
        double distance_end=0;
        for (Location location : optimizedRoute) {
            Path+=location.getName()+" --> ";
            if(cnt==0){
                System.out.println(location.getName()+"\t\t0.00 KM     0.00 H\t\t\t0.00 H");
                begin=location.getName();
            }
            else
                System.out.println(location.getName()+"\t\t"+String.format("%.2f",location.getDistancekm())+" KM\t"+String.format("%.2f",time_calc(location.getEstimated_time()))+" H\t\t\t"+time_calc(location.getDeadline())+" H");
            if(cnt == optimizedRoute.size()-2)
                distance_end = Math.sqrt(Math.pow(location.getLatitude(), 2) + Math.pow(location.getLongitude(), 2));
            cnt++;
        }
        System.out.println(begin+"\t\t"+String.format("%.2f",distance_end)+" KM\t"+String.format("%.2f",time_calc(distance_end*3))+" H\t\t\t  ∞   H");
        System.out.println('\n'+Path.substring(0,Path.length()-4)+"--> "+begin+'\n');
    }

    public static void main(String[] args) {
        CourierRouteCLI courierRouteCLI = new CourierRouteCLI();
        courierRouteCLI.run();
    }
}

/*
Locations		Distance	Estimated time	Deadline
Location 1		0.00 KM     0.00 Min		0.00 Min
Location 10		15.64 KM	46.93 Min		783.0 Min
Location 3		30.66 KM	91.98 Min		844.0 Min
Location 8		40.07 KM	120.20 Min		901.0 Min
Location 5		55.56 KM	166.68 Min		960.0 Min
Location 4		71.14 KM	213.43 Min		1023.0 Min
Location 7		86.70 KM	260.11 Min		1084.0 Min
Location 6		101.61 KM	304.82 Min		1141.0 Min
Location 9		110.00 KM	330.01 Min		1200.0 Min
Location 2		125.72 KM	377.15 Min		1263.0 Min
Location 1		171.30 KM	513.90 Min		     ∞ Min
*/