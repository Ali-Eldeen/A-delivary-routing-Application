package courier;

public class Location {
    private String name;
    private double latitude;
    private double longitude;
    private double distancekm;
    private double estimated_time;
    private boolean isPickup;
    private String time;
    private int deadline;
    public Location(String name, double latitude, double longitude, boolean isPickup, String time){
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.isPickup = isPickup;
        this.time = time;
        String H_M[]=time.split(":");
        this.deadline=Integer.parseInt(H_M[0])*60+Integer.parseInt(H_M[1].substring(0,1));
        if (H_M[1].endsWith("PM"))
            this.deadline+=12*60;
    }

    // Getters and setters for the attributes

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    public double getLatitude() {
        return latitude;
    }
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    public double getLongitude() {
        return longitude;
    }
    public void setEstimated_time(double estimated_time) {
        this.estimated_time = estimated_time;
    }
    public double getEstimated_time() {
        return estimated_time;
    }
    public void setDistancekm(double distancekm) {
        this.distancekm = distancekm;
    }
    public double getDistancekm(){
        return distancekm;
    }
    public void setPickup(boolean pickup) {
        this.isPickup = pickup;
    }
    public boolean isPickup() {
        return isPickup;
    }
    public void setDeadline(int deadline) {
        this.deadline = deadline;
    }
    public int getDeadline() {
        return this.deadline;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public String getTime() {
        return this.time;
    }



}
