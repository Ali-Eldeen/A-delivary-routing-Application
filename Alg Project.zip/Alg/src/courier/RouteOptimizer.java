package courier;

import java.util.*;

public class RouteOptimizer {
    public static List<Location> optimizeRoute(List<Location> locations) {
        // Create a graph to represent the connections between locations
        Map<Location, List<Location>> graph = createGraph(locations);

        // Initialize the distances to all locations as positive infinity
        Map<Location, Double> distances = new HashMap<>();
        for (Location location : locations) {
            distances.put(location, Double.POSITIVE_INFINITY);
        }

        // Set the distance of the starting location to 0
        distances.put(locations.get(0), 0.0);

        // Create a priority queue to store the locations based on their distances
        PriorityQueue<Location> queue = new PriorityQueue<>(Comparator.comparingDouble(distances::get));
        queue.add(locations.get(0));

        // Perform Dijkstra's algorithm to find the shortest path
        while (!queue.isEmpty()) {
            Location currentLocation = queue.poll();

            // Visit the neighbors of the current location
            for (Location next_location : graph.getOrDefault(currentLocation, new ArrayList<>())) {
                double distance = calculateDistance(currentLocation, next_location);

                // Update the distance and the estimated time if a shorter path is found
                if (distances.get(currentLocation) + distance < distances.get(next_location)) {
                    distances.put(next_location, distances.get(currentLocation) + distance);
                    next_location.setDistancekm(distances.get(next_location));
                    next_location.setEstimated_time(distances.get(next_location)*3);
                    queue.remove(next_location); // Remove and re-add to update the priority queue
                    queue.add(next_location);
                }
            }
        }

        // Sort the locations based on their distances
        locations.sort(Comparator.comparingDouble(distances::get));

        return locations;
    }

    private static Map<Location, List<Location>> createGraph(List<Location> locations) {
        Map<Location, List<Location>> graph = new HashMap<>();

        // Create connections between pickup and delivery locations
        for (Location location : locations) {
            if (!location.isPickup()) {
                continue; // Skip delivery locations
            }

            List<Location> neighbors = new ArrayList<>();
            for (Location neighbor : locations) {
                if (neighbor.isPickup() && !neighbor.equals(location)) {
                    neighbors.add(neighbor);
                }
            }

            graph.put(location, neighbors);
        }

        return graph;
    }

    private static double calculateDistance(Location location1, Location location2) {
        double lat1 = location1.getLatitude();
        double lon1 = location1.getLongitude();
        double lat2 = location2.getLatitude();
        double lon2 = location2.getLongitude();
        double distance = Math.sqrt(Math.pow(lat2 - lat1, 2) + Math.pow(lon2 - lon1, 2));
        return distance;
    }
}
